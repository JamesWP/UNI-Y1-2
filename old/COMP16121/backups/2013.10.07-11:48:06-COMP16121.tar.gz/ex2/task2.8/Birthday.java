public class Birthday
{
  public static void main(String[] args)
  {
    System.out.print("Name: " + args[0] + ", " + args[1] + "; ");
    System.out.println("Born: " + args[2]);
  }
}