public class Limerick
{
  public static void main(String[] args)
  {
    System.out.println("There was a young user of Java");
    System.out.println("Whose coding was such a palava!");
    System.out.println("His layout was pooh!");
    System.out.println("So what did we do?");
    System.out.println("We told him to stick to making coffee!");
  }
}