public class Quote
{
  public static void main(String[] args)
  {
    System.out.println("Programming is about making the stupis seam clever.");
    System.out.println("                       _ ^ _                       ");
    System.out.println(                        0 / 0                        );
    System.out.println("                         =                         ");
    System.out.println("           (At least. to the dumb user!)           ");
  }
}