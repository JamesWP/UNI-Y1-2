colSum = sum(A)'
rowSum = sum(A,2)
rowSum==colSum