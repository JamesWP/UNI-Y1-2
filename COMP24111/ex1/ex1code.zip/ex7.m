A*B==A
A.*B