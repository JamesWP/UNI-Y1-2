ints = 1:100;
logedints = log(ints);
plot(ints,logedints,'+');