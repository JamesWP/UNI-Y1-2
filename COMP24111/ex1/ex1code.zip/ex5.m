%the columns in A
sa = size(A)
s = sa(1)
oddCols = A(:,1:2:s)