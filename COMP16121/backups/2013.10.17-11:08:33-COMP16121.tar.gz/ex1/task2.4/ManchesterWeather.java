public class ManchesterWeather
{
  public static void main(String[] args)
  {
    System.out.println("Rainfalls keep dropping on my head!");
  }
}